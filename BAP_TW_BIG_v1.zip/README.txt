BAP_TW_BIG_v1 — Large Berth Allocation with Time Windows dataset
Files:
- bap_terminals.csv: terminal_id,name,berth_capacity
- bap_vessels.csv: vessel_id,type,preferred_terminal,eta_earliest,eta_latest,service_time_hours
- bap_constraints.csv: type,terminal_id,vessel_id,parameter,value,units,note

Notes:
- 40 terminals with capacities 2–8 berths.
- 2000 vessels over a 7-day horizon; ETA windows 2–8h; service times 2.0–10.0h.
- 100 random exclusivity rules (capacity forced to 1 when a specified vessel is present).
