TRAMP_TSP_BIG_v1 — Large TSP/VRP-style dataset
Files:
- tsp_ports.csv: port_id,name,capacity_base,x_nm,y_nm
- tsp_vessels.csv: vessel_id,name,start_node
- tsp_routes.csv: vessel_id,sequence_order,port_id,service_time_hours
- tsp_distances.csv: from_port,to_port,distance_nm,sailing_hours_at_18kn
- tsp_constraints.csv: type,port_id,vessel_id,parameter,value,units,note

Notes:
- 300 ports laid out on a jittered 2D grid (nautical miles). Distances are Euclidean over the plane.
- 120 vessels with 10–25 visits each (distinct ports); service times 1.5–6.0h.
- Base port capacities are 1–6 simultaneous vessels.
- 50 random exclusivity rules: capacity overrides to 1 when a specified vessel is at that port.
